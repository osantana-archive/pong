/* Allegro datafile object indexes, produced by grabber v3.0 + WIP */
/* Datafile: f:\jgmod\examples\yea.dat */
/* Date: Sun Nov  8 00:53:25 1998 */
/* Do not hand edit! */

#define YEAM                             0        /* JGM  */

